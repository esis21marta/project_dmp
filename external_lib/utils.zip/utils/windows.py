from pyspark.sql.window import Window
import pyspark.sql.functions as f
import pandas as pd


def next_week_start_day(date):
    """Returns the next monday for the current day

    Args:
        date: Current date

    Returns:
        next_day: Next monday for the current day
    """
    next_day = f.next_day(date, "monday")
    return next_day


def previous_week_start_day(date):
    """Returns a rolling window

    Args:
        date: Current date

    Returns:
        previous_day: Previous monday for current day
    """
    previous_day = f.date_sub(f.next_day(date, "monday"), 7)
    return previous_day


def get_rolling_window(num_days, key='msisdn', oby='trx_date'):
    """Returns a rolling window paritioned by 'key', ordered by 'oby'
    Args:
        key: Partition by Key
        num_days: Number of days for the rolling window (if negative, will run for full history)
        oby: Order by column

    Returns:
        w: Rolling window of num_days, partitioned by key, ordered by oby
    """

    days = lambda i: (i - 1) * 86400
    if num_days == -1:
        w = (Window().partitionBy(f.col(key))
             .orderBy(f.col(oby).cast("timestamp").cast("long"))
             .rangeBetween(Window.unboundedPreceding, 0))
    else:
        w = (Window().partitionBy(f.col(key))
             .orderBy(f.col(oby).cast("timestamp").cast("long"))
             .rangeBetween(-days(num_days), 0))

    return w


def get_weekly_rolling_window(num_weeks, key='msisdn', oby='weekstart'):
    """Returns a weekly rolling window paritioned by 'key', ordered by 'oby'

    Args:
        key: Partition by Key
        num_weeks: Number of weeks for the rolling window
        oby: Order by column
    Returns:
        w: Rolling window of num_days, partitioned by key, ordered by oby
    """

    w = (Window().partitionBy(f.col(key))
         .orderBy(oby)
         .rowsBetween(num_weeks - 1, 0))
    return w


def get_window_to_pick_last_row(key='msisdn', order_by="trx_date"):
    """Returns a rolling window

    Args:
        key: Partition by Key

    Returns:
        w: Rolling window (paritioned by key, weekstart, ordered by trx_date desc)
    """

    window_pick_up_last_row = (Window()
                               .partitionBy([f.col(key), f.col("weekstart")])
                               .orderBy(f.col(order_by).desc()))
    return window_pick_up_last_row


def get_window_pby_msisdn_oby_trx_date(partition_column="msisdn", order_by_column="trx_date"):
    """Returns a rolling window partitioned by partition_column, ordered by order_by_column

    Args:
        partition_column: Partition by Key
        order_by_column: Order by column

    Returns:
        w: Rolling window parititioned by partition_column ordered by order_by_column
    """
    window_sort_by_trx_date = (Window()
                               .partitionBy(partition_column)
                               .orderBy(f.col(order_by_column)))
    return window_sort_by_trx_date


def create_date_list_weekly(start_date: str, end_date: str) -> list:
    """
    Function to return a list of all Monday dates between start_date & end_date
    :param start_date: Beginning of the date range for which all Mondays are required
    :param end_date: Ending of the date range for which all Mondays are required
    :return: List of all Monday's in the given date range
    """
    return [d.strftime('%Y-%m-%d') for d in pd.date_range(start_date, end_date, freq='W-MON')]


def create_date_list_daily(start_date: str, end_date: str) -> list:
    """
    Function to return a list of all dates between start_date & end_date
    :param start_date: Beginning of the date range for which all dates are required
    :param end_date: Ending of the date range for which all dates are required
    :return: List of all dates in the given date range
    """
    return [d.strftime('%Y-%m-%d') for d in pd.date_range(start_date, end_date)]
