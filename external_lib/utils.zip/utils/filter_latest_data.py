import pyspark
import pyspark.sql.functions as f


def filter_latest_data(
    df_data: pyspark.sql.DataFrame, partition_column_name: str
) -> pyspark.sql.DataFrame:
    """
    Filters Latest Partition Data

    :param df_data: Data DataFrame

    :param partition_column_name: Partition Column Name

    :return: Latest Partition Data
    """

    df_latest_week = df_data.agg(
        f.max(f.col(partition_column_name)).alias(partition_column_name)
    )

    df_latest_data = df_data.join(
        df_latest_week, [partition_column_name], how="inner"
    )

    return df_latest_data
